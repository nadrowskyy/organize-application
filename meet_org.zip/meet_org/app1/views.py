from django.shortcuts import render

def home(request):
	dzialanie = "(14+7*21)/4"
	#rownanie_str = rownanie
	wynik = eval(dzialanie)
	return render(request, 
		'home.html', {
		"show_dzialanie": dzialanie,
		"show_wynik": wynik,
		#"rownanie_str": rownanie_str
		})
