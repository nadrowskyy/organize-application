Open index.html in any browser.
For mor details, see: https://www.geekinsta.com/creating-a-table-with-search-sorting-and-paging/